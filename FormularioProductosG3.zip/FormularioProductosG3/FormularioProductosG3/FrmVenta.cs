﻿using System;
using System.Data;
using System.Windows.Forms;

namespace FormularioProductosG3
{
    public partial class FrmVenta : Form
    {
        ServiceProductosCompleto.ServicioCompletoSoapClient ws =
            new ServiceProductosCompleto.ServicioCompletoSoapClient();

        DataTable dtProductosAgregados = new DataTable();

        public FrmVenta()
        {
            InitializeComponent();
            this.Load += new System.EventHandler(this.FrmVenta_Load);
            this.btnSeleccionar.Click += new System.EventHandler(this.btnSeleccionar_Click);
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            this.dgvProductosAgregados.CellEndEdit += new DataGridViewCellEventHandler(this.dgvProductosAgregados_CellEndEdit);
        }

        private void FrmVenta_Load(object sender, EventArgs e)
        {
            CargarClientes();
            CargarProductos();
            CrearTablaTemporal();
        }

        private void CrearTablaTemporal()
        {
            dtProductosAgregados.Columns.Add("IdProducto", typeof(int));
            dtProductosAgregados.Columns.Add("Nombre", typeof(string));
            dtProductosAgregados.Columns.Add("Cantidad", typeof(int));

            dgvProductosAgregados.DataSource = dtProductosAgregados;

           
            dgvProductosAgregados.Columns["Cantidad"].ReadOnly = false;
        }

        private void CargarClientes()
        {
            var lista = ws.ListarClientes();

            cmbClientes.DataSource = lista;
            cmbClientes.DisplayMember = "Nombre";
            cmbClientes.ValueMember = "IdCliente";
        }

        private void CargarProductos()
        {
            var lista = ws.ListarProductos();
            dgvProductos.DataSource = lista;
        }

        private void btnSeleccionar_Click(object sender, EventArgs e)
        {
            if (dgvProductos.CurrentRow != null)
            {
                MessageBox.Show("Producto seleccionado: " +
                    dgvProductos.CurrentRow.Cells["Nombre"].Value.ToString());
            }
        }

    
        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbClientes.SelectedValue == null)
                {
                    MessageBox.Show("Seleccione cliente");
                    return;
                }

                if (dtProductosAgregados.Rows.Count == 0)
                {
                    MessageBox.Show("Agregue productos");
                    return;
                }

                foreach (DataRow row in dtProductosAgregados.Rows)
                {
                    int idProducto = Convert.ToInt32(row["IdProducto"]);
                    int cantidad = Convert.ToInt32(row["Cantidad"]);

                    foreach (DataGridViewRow prod in dgvProductos.Rows)
                    {
                        if (Convert.ToInt32(prod.Cells["IdProducto"].Value) == idProducto)
                        {
                            int stock = Convert.ToInt32(prod.Cells["Existencia"].Value);

                            if (cantidad > stock)
                            {
                                MessageBox.Show("Stock insuficiente para el producto: " + prod.Cells["Nombre"].Value);
                                return;
                            }
                        }
                    }
                }

                string idCliente = cmbClientes.SelectedValue.ToString();

                foreach (DataRow row in dtProductosAgregados.Rows)
                {
                    int idProducto = Convert.ToInt32(row["IdProducto"]);
                    int cantidad = Convert.ToInt32(row["Cantidad"]);

                    var respuesta = ws.RegistrarVenta(idCliente, idProducto, cantidad);

                    if (!respuesta.Exito)
                    {
                        MessageBox.Show("Error: " + respuesta.Mensaje);
                        return;
                    }
                }

                MessageBox.Show("Venta registrada correctamente");

                dtProductosAgregados.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (dgvProductos.CurrentRow == null) return;

            int idProducto = (int)dgvProductos.CurrentRow.Cells["IdProducto"].Value;
            string nombre = dgvProductos.CurrentRow.Cells["Nombre"].Value.ToString();
            int stock = Convert.ToInt32(dgvProductos.CurrentRow.Cells["Existencia"].Value);

            int cantidadInicial = 1;

            if (cantidadInicial > stock)
            {
                MessageBox.Show("No hay suficiente stock");
                return;
            }

            dtProductosAgregados.Rows.Add(idProducto, nombre, cantidadInicial);
        }

        private void dgvProductosAgregados_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvProductosAgregados.Columns["Cantidad"].Index)
            {
                int cantidad = Convert.ToInt32(dgvProductosAgregados.Rows[e.RowIndex].Cells["Cantidad"].Value);
                int idProducto = Convert.ToInt32(dgvProductosAgregados.Rows[e.RowIndex].Cells["IdProducto"].Value);

                foreach (DataGridViewRow row in dgvProductos.Rows)
                {
                    if (Convert.ToInt32(row.Cells["IdProducto"].Value) == idProducto)
                    {
                        int stock = Convert.ToInt32(row.Cells["Existencia"].Value);

                        if (cantidad > stock)
                        {
                            MessageBox.Show("Stock insuficiente");

                            // Ajusta automáticamente al máximo disponible
                            dgvProductosAgregados.Rows[e.RowIndex].Cells["Cantidad"].Value = stock;
                        }
                        break;
                    }
                }
            }
        }
    }
}